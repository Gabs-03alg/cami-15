
import React from 'react';

const Card: React.FC<{ children: React.ReactNode; title?: string; bg?: string }> = ({ children, title, bg = 'bg-white' }) => (
  <div className={`p-12 md:p-24 border-b border-gray-100/60 text-center ${bg} last:border-0 relative overflow-hidden`}>
    {title && (
      <div className="flex flex-col items-center mb-12">
        <h3 className="font-serif text-[10px] md:text-[11px] tracking-[0.5em] uppercase text-gray-400 font-medium">
          {title}
        </h3>
        <div className="w-6 h-[1px] bg-[#F6A5C0]/30 mt-4"></div>
      </div>
    )}
    {children}
  </div>
);

export const EditorialInfo: React.FC = () => {
  return (
    <section id="event-details" className="max-w-4xl mx-auto shadow-2xl shadow-gray-200/50 my-24 bg-white">
      
      {/* Save the Date */}
      <Card title="The Date">
        <div className="flex flex-col items-center">
            <div className="flex items-baseline gap-1 mb-2">
              <span className="font-serif text-8xl md:text-[10rem] text-[#F6A5C0] font-black tracking-tighter leading-none">14</span>
            </div>
            <span className="font-serif text-xl md:text-2xl uppercase tracking-[0.3em] text-gray-800 font-light mb-1">Marzo</span>
            <span className="font-script text-5xl text-[#D44D5C]/80 mt-[-0.5rem]">2026</span>
            
            <div className="flex items-center gap-4 mt-8">
              <div className="h-[1px] w-8 bg-gray-200"></div>
              <span className="font-serif italic text-lg tracking-widest text-gray-400">Dos de la tarde</span>
              <div className="h-[1px] w-8 bg-gray-200"></div>
            </div>
        </div>
      </Card>

      {/* When & Where */}
      <Card title="The Place" bg="bg-[#BFD9F2]/5">
        <h2 className="font-serif text-3xl md:text-5xl text-gray-800 mb-4 tracking-tight">Campo Verde CAES</h2>
        <p className="font-serif italic text-gray-500 text-lg md:text-xl mb-10 leading-relaxed max-w-sm mx-auto">
          Kilómetro 18.5, Carretera a El Salvador, Guatemala.
        </p>
        <a 
          href="https://waze.com/ul" 
          target="_blank" 
          rel="noopener noreferrer"
          className="inline-block border border-gray-800/10 px-10 py-4 text-[10px] tracking-[0.4em] uppercase hover:bg-gray-900 hover:text-white hover:border-gray-900 transition-all duration-500 font-medium bg-white shadow-sm"
        >
          Ver Ubicación
        </a>
      </Card>

      {/* Dress Code */}
      <Card title="The Dress Code">
        <div className="max-w-md mx-auto">
          <p className="font-serif text-2xl md:text-3xl text-gray-700 mb-8 italic tracking-tight">Garden Casual-Chic</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-[11px] tracking-[0.15em] uppercase text-gray-400 font-semibold border-t border-gray-50 pt-8">
            <div className="flex items-center justify-center gap-3">
              <span className="w-1.5 h-1.5 rounded-full bg-[#F6A5C0]"></span>
              <span>No Rosa</span>
            </div>
            <div className="flex items-center justify-center gap-3">
              <span className="w-1.5 h-1.5 rounded-full bg-gray-300"></span>
              <span>No Jeans</span>
            </div>
          </div>
        </div>
      </Card>

      {/* Gift */}
      <Card title="The Gift" bg="bg-[#CFE8D8]/5">
        <div className="max-w-lg mx-auto">
          <p className="font-script text-4xl text-gray-700 mb-8 leading-tight">Cero drama. Cero ‘¿qué le compro?’.</p>
          <div className="relative p-8 border border-white bg-white/40 shadow-inner">
            <p className="font-serif text-lg leading-relaxed text-gray-500 italic">
              “Entre alfajores y una aventura rumbo a Bariloche… la lluvia de sobres o transferencias será mi mejor outfit.”
            </p>
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#CFE8D8] w-6 h-[1px]"></div>
          </div>
        </div>
      </Card>

      {/* RSVP */}
      <Card title="The Invitation" bg="bg-white">
        <div className="max-w-sm mx-auto">
          <h2 className="font-serif text-4xl md:text-5xl mb-6 italic text-gray-800 tracking-tighter">¿Vienes o qué?</h2>
          <p className="text-gray-400 mb-12 font-serif italic text-base">
            Tu presencia es nuestro mejor regalo. <br/>
            <span className="text-[10px] tracking-[0.3em] uppercase font-bold not-italic mt-2 inline-block">Confirmar antes del 28 feb</span>
          </p>
          
          <div className="mb-14">
              <h4 className="font-serif text-2xl mb-1 text-[#F6A5C0] font-medium tracking-tight">Cami Guerra Alarcón</h4>
              <p className="text-[9px] tracking-[0.5em] uppercase text-gray-300 font-bold">XV Años</p>
          </div>
          
          <button className="w-full bg-[#F6A5C0] text-white py-5 rounded-sm font-serif italic text-xl shadow-2xl shadow-[#F6A5C0]/40 hover:bg-[#eb94b1] hover:-translate-y-1 transition-all duration-500 tracking-wide">
            Confirmar Asistencia
          </button>
        </div>
      </Card>

    </section>
  );
};
