
import React from 'react';

interface EnvelopeProps {
  isOpen: boolean;
  onOpen: () => void;
}

export const Envelope: React.FC<EnvelopeProps> = ({ isOpen, onOpen }) => {
  return (
    <section className="h-screen flex flex-col items-center justify-center p-6 relative overflow-hidden bg-white">
      {/* Fondo con patrón floral de hojas verdes minimalista */}
      <div className="absolute inset-0 z-0 pointer-events-none">
         <img 
            src="https://images.unsplash.com/photo-1618367588411-d9a90fefa881?auto=format&fit=crop&q=80&w=2000" 
            alt="floral background pattern" 
            className="w-full h-full object-cover opacity-40 mix-blend-multiply"
         />
         <div className="absolute inset-0 bg-white/10 backdrop-blur-[0.5px]"></div>
      </div>

      {/* Texto de introducción sobre el sobre */}
      <div className={`z-10 text-center mb-10 transition-all duration-700 ${isOpen ? 'opacity-0 -translate-y-8' : 'opacity-100 translate-y-0'}`}>
        <h2 className="font-serif italic text-4xl text-gray-800 drop-shadow-sm tracking-tight">¿Estás listo?</h2>
      </div>

      <div 
        className={`relative w-80 h-72 transition-all duration-1000 transform cursor-pointer z-10 ${isOpen ? 'scale-150 opacity-0 rotate-6 pointer-events-none' : 'hover:scale-105 hover:-rotate-1 active:scale-95'}`}
        onClick={onOpen}
      >
        {/* Cuerpo del sobre */}
        <div className="absolute inset-0 bg-white shadow-[0_40px_100px_rgba(0,0,0,0.08)] rounded-sm border border-gray-100 flex flex-col items-center justify-between py-12 overflow-hidden">
            <div className="absolute top-0 w-full h-full bg-[#FCFAF8] transform rotate-45 -translate-y-1/2 border-b border-gray-100"></div>
            
            <div className="h-4 w-full"></div>

            {/* Sello de lacre */}
            <div className="relative z-10 w-24 h-24 flex items-center justify-center transform transition-transform duration-300">
              <div className="absolute inset-0 bg-[#D44D5C] rounded-[48%_52%_50%_50%/_50%_48%_52%_50%] shadow-[0_8px_16px_rgba(0,0,0,0.3),inset_0_2px_4px_rgba(255,255,255,0.4),inset_0_-4px_6px_rgba(0,0,0,0.3)]"></div>
              <div className="absolute inset-3 border-2 border-white/10 rounded-full"></div>
              <div className="relative z-20">
                <span className="font-serif text-[#7f1d1d] text-4xl font-bold tracking-tighter mix-blend-multiply opacity-60 translate-y-[1px]">C</span>
                <span className="absolute inset-0 font-serif text-white/40 text-4xl font-bold tracking-tighter -translate-y-[1px] -translate-x-[0.5px]">C</span>
              </div>
            </div>
            
            {/* Call to action en el sobre */}
            <div className="relative z-10 text-center px-6 mt-auto">
              <p className="font-script text-3xl text-[#F6A5C0] leading-none mb-2">
                toca el sobre…
              </p>
              <p className="font-serif text-[11px] tracking-[0.25em] uppercase text-gray-400 font-semibold">
                y acepta tu destino 💌
              </p>
            </div>
        </div>
      </div>
      
      {/* Blurs decorativos suaves */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-[#CFE8D8]/20 blur-[100px]"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-[#F6A5C0]/10 blur-[120px]"></div>
    </section>
  );
};
