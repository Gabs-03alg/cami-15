
import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="pb-20 pt-10 text-center opacity-60">
      <div className="flex flex-col items-center gap-2">
        <div className="w-12 h-12 rounded-full border border-gray-300 flex items-center justify-center mb-4">
           <span className="font-serif text-[#F6A5C0] font-bold">C</span>
        </div>
        <p className="font-serif text-xs tracking-widest text-gray-400">Made with 💖</p>
      </div>
    </footer>
  );
};
