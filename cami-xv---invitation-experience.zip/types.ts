
export interface EventDetails {
  date: string;
  time: string;
  location: string;
  address: string;
}
